from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class Transaction:
    id: str
    name: str
    domain: str
    current_revenue_dependency: float = 0.5
    ai_substitutability: float = 0.5
    marginal_cost_collapse: float = 0.5
    trust_requirement: float = 0.5
    verification_cost: float = 0.5
    regulation_pressure: float = 0.5
    platform_disintermediation: float = 0.5
    public_value: float = 0.5
    ethical_risk: float = 0.3

@dataclass
class Actor:
    id: str
    name: str
    role: str
    assets: List[str] = field(default_factory=list)
    trust_assets: float = 0.5
    real_world_coordination: float = 0.5
    learning_velocity: float = 0.5
    capital_resilience: float = 0.5
    ethical_constraint: float = 0.5
    public_legitimacy: float = 0.5

@dataclass
class Case:
    case_id: str
    title: str
    thesis: str
    actors: List[Actor]
    transactions: List[Transaction]
    assumptions: Dict[str, Any] = field(default_factory=dict)
