# Optional streamlit app placeholder. The offline standalone interface is index.html.
