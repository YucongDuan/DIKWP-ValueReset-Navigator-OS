import csv, json, math, hashlib
from pathlib import Path
from typing import Dict, List, Any
from .models import Actor, Transaction, Case

BLOCK_TERMS = [
    "insider trading", "market manipulation", "pump and dump", "front running",
    "credential fraud", "exploit vulnerable", "surveillance", "coerce", "blackmail",
    "bribe", "evade regulation", "deceptive pricing", "fake certification"
]

OPPORTUNITY_ARCHETYPES = [
    "trust_infrastructure_builder",
    "accountable_steward",
    "human_judgment_partner",
    "real_world_coordination_broker",
    "public_value_investor",
    "authenticity_and_provenance_curator",
    "ai_governance_reviewer",
    "capability_conversion_mentor"
]

def clamp(x):
    return max(0.0, min(1.0, float(x)))

def load_case(path: str) -> Case:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    actors = [Actor(**a) for a in data.get("actors", [])]
    txs = [Transaction(**t) for t in data.get("transactions", [])]
    return Case(data.get("case_id", "case"), data.get("title", "Untitled"), data.get("thesis", ""), actors, txs, data.get("assumptions", {}))

def transaction_failure_risk(t: Transaction) -> float:
    raw = (
        0.22*t.ai_substitutability +
        0.18*t.marginal_cost_collapse +
        0.16*t.platform_disintermediation +
        0.14*t.verification_cost +
        0.12*t.regulation_pressure +
        0.10*t.current_revenue_dependency +
        0.08*max(0, t.trust_requirement - t.public_value)
    )
    return round(clamp(raw), 3)

def value_reset_opportunity(t: Transaction) -> float:
    # High if transaction is failing but public value and trust requirements create a new stewardship role.
    f = transaction_failure_risk(t)
    raw = 0.36*f + 0.22*t.public_value + 0.18*t.trust_requirement + 0.12*(1-t.ethical_risk) + 0.12*t.regulation_pressure
    return round(clamp(raw), 3)

def actor_transition_readiness(a: Actor) -> float:
    raw = 0.22*a.trust_assets + 0.20*a.real_world_coordination + 0.18*a.learning_velocity + 0.15*a.ethical_constraint + 0.15*a.public_legitimacy + 0.10*a.capital_resilience
    return round(clamp(raw), 3)

def capture_risk_actor(a: Actor) -> float:
    raw = 0.35*(1-a.ethical_constraint) + 0.25*(1-a.public_legitimacy) + 0.20*a.capital_resilience + 0.20*(1-a.learning_velocity)
    return round(clamp(raw), 3)

def route_transaction(t: Transaction) -> str:
    f = transaction_failure_risk(t)
    o = value_reset_opportunity(t)
    if t.ethical_risk > 0.78:
        return "blocked_or_redesign_extractive_strategy"
    if f >= 0.70 and o >= 0.62:
        return "urgent_value_reset_pilot"
    if f >= 0.55:
        return "transition_now"
    if o >= 0.65:
        return "build_trust_moat"
    return "monitor_and_option_build"

def choose_archetype(t: Transaction) -> str:
    if t.trust_requirement > 0.75 and t.verification_cost > 0.55:
        return "authenticity_and_provenance_curator"
    if t.regulation_pressure > 0.65:
        return "ai_governance_reviewer"
    if t.public_value > 0.75:
        return "public_value_investor"
    if t.ai_substitutability > 0.65 and t.trust_requirement > 0.55:
        return "human_judgment_partner"
    if t.platform_disintermediation > 0.65:
        return "real_world_coordination_broker"
    return "capability_conversion_mentor"

def dikwp_ledger(case: Case) -> Dict[str, Any]:
    entries = []
    for t in case.transactions:
        entries.append({
            "id": t.id,
            "type": "transaction",
            "D": {"name": t.name, "domain": t.domain, "current_revenue_dependency": t.current_revenue_dependency},
            "I": {"failure_risk": transaction_failure_risk(t), "route": route_transaction(t)},
            "K": {"mechanism": "AI may collapse marginal cost, increase verification demand, and reprice trust-bearing human roles."},
            "W": {"public_value": t.public_value, "ethical_risk": t.ethical_risk},
            "P": {"purpose": "convert failing transaction into capability, trust, stewardship, or public-value opportunity"},
            "R": {"reliability": "prototype heuristic", "kill": "actual market data contradicts assumptions"}
        })
    for a in case.actors:
        entries.append({
            "id": a.id,
            "type": "actor",
            "D": {"name": a.name, "role": a.role, "assets": a.assets},
            "I": {"transition_readiness": actor_transition_readiness(a), "capture_risk": capture_risk_actor(a)},
            "K": {"mechanism": "Elite advantage must shift from rent extraction to accountable stewardship and public value conversion."},
            "W": {"ethical_constraint": a.ethical_constraint, "public_legitimacy": a.public_legitimacy},
            "P": {"purpose": "redefine role and portfolio under AI transaction failure"},
            "R": {"reliability": "self/analyst input dependent", "kill": "observed behavior contradicts stated constraints"}
        })
    return {"case_id": case.case_id, "entries": entries}

def analyze(case: Case) -> Dict[str, Any]:
    txs = []
    for t in case.transactions:
        txs.append({
            "id": t.id,
            "name": t.name,
            "domain": t.domain,
            "transaction_failure_risk": transaction_failure_risk(t),
            "value_reset_opportunity": value_reset_opportunity(t),
            "route": route_transaction(t),
            "opportunity_archetype": choose_archetype(t),
            "public_value": t.public_value,
            "ethical_risk": t.ethical_risk
        })
    actors = []
    for a in case.actors:
        actors.append({
            "id": a.id,
            "name": a.name,
            "role": a.role,
            "transition_readiness": actor_transition_readiness(a),
            "capture_risk": capture_risk_actor(a),
            "route": "stewardship_transition" if actor_transition_readiness(a) >= 0.65 and capture_risk_actor(a) < 0.55 else "ethics_and_capability_rebuild"
        })
    mean_fail = round(sum(x["transaction_failure_risk"] for x in txs)/len(txs), 3) if txs else 0
    mean_opp = round(sum(x["value_reset_opportunity"] for x in txs)/len(txs), 3) if txs else 0
    mean_ready = round(sum(x["transition_readiness"] for x in actors)/len(actors), 3) if actors else 0
    blocked = sum(1 for x in txs if x["route"] == "blocked_or_redesign_extractive_strategy")
    return {
        "system": "DIKWP ValueReset Navigator OS",
        "version": "0.1.0",
        "case_id": case.case_id,
        "title": case.title,
        "summary": {
            "transaction_count": len(txs),
            "actor_count": len(actors),
            "mean_transaction_failure_risk": mean_fail,
            "mean_value_reset_opportunity": mean_opp,
            "mean_actor_transition_readiness": mean_ready,
            "blocked_or_redesign_count": blocked,
            "overall_route": "launch_value_reset_lab" if mean_opp >= 0.55 else "monitor_and_build_options"
        },
        "transactions": txs,
        "actors": actors,
        "action_boundary": "Strategy, learning, governance and transition planning only; no illicit trading, manipulation, coercion, or automated high-impact decisions."
    }

def write_outputs(case: Case, outdir: str):
    p = Path(outdir); p.mkdir(parents=True, exist_ok=True)
    report = analyze(case)
    (p/"value_reset_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    ledger = dikwp_ledger(case)
    (p/"dikwp_value_ledger.json").write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    with (p/"transaction_failure_matrix.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["id","name","domain","transaction_failure_risk","value_reset_opportunity","route","opportunity_archetype","public_value","ethical_risk"])
        w.writeheader(); w.writerows(report["transactions"])
    with (p/"opportunity_map.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["transaction_id","opportunity_archetype","first_offer","trust_moat","public_value_conversion"])
        w.writeheader()
        for t in report["transactions"]:
            w.writerow({
                "transaction_id": t["id"],
                "opportunity_archetype": t["opportunity_archetype"],
                "first_offer": "90-day DIKWP value reset pilot",
                "trust_moat": "evidence ledger + human accountability + audit trail",
                "public_value_conversion": "redirect rents into capability, trust, and local resilience"
            })
    with (p/"action_tickets.csv").open("w", newline="", encoding="utf-8") as f:
        fields=["ticket_id","owner","priority","action","evidence_refs","kill_condition","rollback"]
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for i,t in enumerate(report["transactions"],1):
            priority = "high" if t["route"] in ["urgent_value_reset_pilot","blocked_or_redesign_extractive_strategy"] else "medium"
            w.writerow({"ticket_id":f"VR-{i:03d}","owner":"transition steward","priority":priority,"action":f"Design {t['opportunity_archetype']} for {t['name']}","evidence_refs":t['id'],"kill_condition":"strategy relies on deception, coercion, or unverified legal assumptions","rollback":"downgrade to research-only or ethics review"})
    plan = render_transition_plan(case, report)
    (p/"elite_transition_plan.md").write_text(plan, encoding="utf-8")
    (p/"governance_boundary.md").write_text(render_boundary(), encoding="utf-8")
    return report

def render_transition_plan(case: Case, report: Dict[str,Any]) -> str:
    lines = [f"# DIKWP ValueReset Transition Plan", "", f"Case: {case.title}", "", "## Executive Judgment", "", "The transition opportunity is not to preserve old transaction rents. It is to convert reputation, capital, expertise, networks, and institutional access into accountable stewardship under AI-driven value reset.", "", "## Priority Transaction Failures", ""]
    for t in sorted(report["transactions"], key=lambda x: x["transaction_failure_risk"], reverse=True):
        lines += [f"### {t['name']}", f"- Failure risk: {t['transaction_failure_risk']}", f"- Reset opportunity: {t['value_reset_opportunity']}", f"- Route: {t['route']}", f"- Archetype: {t['opportunity_archetype']}", ""]
    lines += ["## 30/60/90 Day Path", "", "### First 30 days", "- Inventory fragile revenue streams.", "- Identify which transactions are losing trust, scarcity, or verification power.", "- Create a no-deception boundary: no predatory arbitrage, no hidden manipulation, no false credentialing.", "- Select one high-public-value transition pilot.", "", "### Days 31-60", "- Build evidence ledger and trust protocol.", "- Convert one failing transaction into a service with audit, accountability, and human judgment.", "- Create public value narrative and stakeholder map.", "", "### Days 61-90", "- Launch minimum viable value reset pilot.", "- Measure demand, trust, conversion cost, and social legitimacy.", "- Kill or redesign any opportunity dependent on coercion, information asymmetry, or externalized harm.", "", "## Core Rule", "", "If the opportunity only works by hiding cost, exploiting anxiety, or capturing a locked-in party, it is not a value reset opportunity. It is extraction disguised as strategy."]
    return "\n".join(lines)

def render_boundary() -> str:
    return """# Governance Boundary

Allowed uses:
- strategic transition planning
- ethical opportunity design
- AI-augmented leadership education
- professional reinvention
- family office / foundation / enterprise portfolio reflection
- public value conversion
- organization redesign

Blocked uses:
- insider trading
- market manipulation
- front running
- pump and dump
- predatory debt
- credential fraud
- discriminatory exclusion
- covert surveillance
- coercive elite capture
- fake certification
- illegal regulatory evasion
- exploiting vulnerable populations

Every output must be treated as a planning artifact, not legal, financial, medical, or investment advice.
"""

