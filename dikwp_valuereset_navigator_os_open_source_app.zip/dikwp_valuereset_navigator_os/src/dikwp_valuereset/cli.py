import argparse, json
from pathlib import Path
from .analyzer import load_case, write_outputs, BLOCK_TERMS
from .static_audit import write_audit

def guard_text(text: str):
    low=text.lower()
    hits=[t for t in BLOCK_TERMS if t in low]
    if hits:
        return {"decision":"block_and_reframe", "hits":hits, "safe_redirect":"Use ethical transition planning, public-value conversion, and accountable stewardship."}
    return {"decision":"allow_strategy_planning", "hits":[], "safe_redirect":"Proceed with DIKWP evidence, residual, kill/recovery, and action boundary."}

def main(argv=None):
    p=argparse.ArgumentParser(prog="valuereset")
    sub=p.add_subparsers(dest="cmd", required=True)
    a=sub.add_parser("analyze")
    a.add_argument("case")
    a.add_argument("--out", default="outputs/demo")
    g=sub.add_parser("guard")
    g.add_argument("text")
    s=sub.add_parser("static-audit")
    s.add_argument("root")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args=p.parse_args(argv)
    if args.cmd=="analyze":
        case=load_case(args.case)
        report=write_outputs(case, args.out)
        print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    elif args.cmd=="guard":
        print(json.dumps(guard_text(args.text), ensure_ascii=False, indent=2))
    elif args.cmd=="static-audit":
        print(json.dumps(write_audit(args.root, args.out), ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
