from pathlib import Path
import json
import ast

BANNED_IMPORTS = {"requests", "urllib", "socket", "subprocess", "selenium", "playwright", "pyautogui", "pynput"}
BANNED_CALLS = {"eval", "exec", "system", "popen"}
BANNED_ATTRS = {"os.system", "os.popen", "subprocess.run", "subprocess.Popen", "subprocess.call"}

def _imports_and_calls(path: Path):
    findings=[]
    text=path.read_text(encoding="utf-8", errors="ignore")
    try:
        tree=ast.parse(text)
    except SyntaxError as e:
        return [{"file": str(path), "issue": "syntax_error", "detail": str(e)}]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                base=alias.name.split('.')[0]
                if base in BANNED_IMPORTS:
                    findings.append({"file": str(path), "issue":"banned_import", "detail": alias.name})
        elif isinstance(node, ast.ImportFrom):
            base=(node.module or '').split('.')[0]
            if base in BANNED_IMPORTS:
                findings.append({"file": str(path), "issue":"banned_import", "detail": node.module})
        elif isinstance(node, ast.Call):
            func=node.func
            if isinstance(func, ast.Name) and func.id in BANNED_CALLS:
                findings.append({"file": str(path), "issue":"banned_call", "detail": func.id})
            elif isinstance(func, ast.Attribute):
                # Detect simple os.system-like calls without false positives in strings.
                name=func.attr
                if name in BANNED_CALLS:
                    findings.append({"file": str(path), "issue":"banned_attr_call", "detail": name})
    return findings

def audit(root: str):
    findings=[]
    for path in Path(root).rglob("*.py"):
        findings.extend(_imports_and_calls(path))
    return {"pass": not findings, "finding_count": len(findings), "findings": findings, "policy":"No network imports, subprocess, dynamic execution, browser automation, credential capture, trading execution, hidden telemetry, or host mutation in offline core."}

def write_audit(root: str, out: str):
    data=audit(root)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data
