# User Manual

## Browser

Open `index.html`, choose a scenario, review the dashboard, and export results.

## CLI

```bash
valuereset analyze examples/sample_value_reset_case.json --out outputs/demo
```

## Interpret scores

- Transaction Failure Risk: likelihood that the old transaction loses pricing power.
- Value Reset Opportunity: likelihood that a new trust/accountability role can be created.
- Transition Readiness: actor's readiness for ethical reinvention.
- Capture Risk: risk that transition becomes extraction.
