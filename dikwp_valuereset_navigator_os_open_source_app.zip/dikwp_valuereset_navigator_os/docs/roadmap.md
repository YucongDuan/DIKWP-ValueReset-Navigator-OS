# Roadmap

## v0.1
Offline prototype, CLI, standalone HTML, demo case.

## v0.2
Add sector templates: professional services, education, finance, healthcare, real estate, media, governance.

## v0.3
Add value reset workshops and team mode.

## v0.4
Integrate TrustPassport and PilotFactory.

## v1.0
Launch DIKWP ValueReset registry and certification program.
