from pathlib import Path
from dikwp_valuereset.analyzer import load_case, analyze, write_outputs
from dikwp_valuereset.cli import guard_text
from dikwp_valuereset.static_audit import audit

ROOT = Path(__file__).resolve().parents[1]

def test_analyze_demo():
    case = load_case(str(ROOT/'examples/sample_value_reset_case.json'))
    report = analyze(case)
    assert report['summary']['transaction_count'] == 4
    assert report['summary']['blocked_or_redesign_count'] == 1
    assert report['summary']['mean_value_reset_opportunity'] > 0.4


def test_outputs(tmp_path):
    case = load_case(str(ROOT/'examples/sample_value_reset_case.json'))
    write_outputs(case, str(tmp_path))
    assert (tmp_path/'value_reset_report.json').exists()
    assert (tmp_path/'transaction_failure_matrix.csv').exists()
    assert (tmp_path/'elite_transition_plan.md').exists()


def test_guard():
    assert guard_text('ethical transition planning')['decision'] == 'allow_strategy_planning'
    assert guard_text('market manipulation plan')['decision'] == 'block_and_reframe'


def test_static_audit():
    res = audit(str(ROOT/'src'))
    assert res['pass'] is True
