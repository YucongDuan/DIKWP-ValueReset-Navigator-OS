# Governance Boundary

Allowed uses:
- strategic transition planning
- ethical opportunity design
- AI-augmented leadership education
- professional reinvention
- family office / foundation / enterprise portfolio reflection
- public value conversion
- organization redesign

Blocked uses:
- insider trading
- market manipulation
- front running
- pump and dump
- predatory debt
- credential fraud
- discriminatory exclusion
- covert surveillance
- coercive elite capture
- fake certification
- illegal regulatory evasion
- exploiting vulnerable populations

Every output must be treated as a planning artifact, not legal, financial, medical, or investment advice.
